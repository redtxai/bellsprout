1 - BAIXA O XAMPP -> https://www.apachefriends.org/download.html
2 - ENTRA NO PHPMYADMIN
3 - CRIA O BANCO "bellspout"
4 - SELECIONA O BANCO E IMPORTA O ARQUIVO -> ARQUIVO bellsprout.sql